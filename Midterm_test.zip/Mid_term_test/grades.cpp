#include "grades.h"

vector<int> sort_grades(vector<int> grades)

{
	//initialize values 
	int a{ 0 };
	int b{ 0 };
	int c{ 0 };
	int d{ 0 };
	int f{ 0 };
	for (auto g : grades) {
		if (g >= 90) { a++; }
		else if (g >= 80) { b++; }
		else if (g >= 70) { c++; }
		else if (g >= 60) { d++; }
		else { f++; }


	}
	vector<int>grade_count{ a,b,c,d,f };
	return grade_count;

}
