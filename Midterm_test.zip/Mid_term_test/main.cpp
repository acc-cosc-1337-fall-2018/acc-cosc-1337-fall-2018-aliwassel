#include"dna.h"
#include "shape.h"
#include"grades.h"
#include"string.h"
#include"receipt.h"

using namespace std;


int main()
{
	string dna1 = "AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGC";
	std::cout << "DNA Count" << "\n";

	vector <int> show_dna = count_dna(dna1);

	cout << "A " << show_dna[0] << endl;
	cout << "C " << show_dna[1] << endl;
	cout << "G " << show_dna[2] << endl;
	cout << "T " << show_dna[3] << endl;



	vector<int>grade_list{ 90,90,90,90, 82,80,80,80,70,72,70,75,71,60,62,62,65,20,30,40 };
	//3rd vector to show hold vlaue passed to the sort_grade function
	auto show_grade = sort_grades(grade_list);
	cout << "Here are the grade" << "\n";
	cout << "_____" << endl;

	cout << "A" << " | " << show_grade[0] << "|" << endl;
	cout << "B" << " | " << show_grade[1] << "|" << endl;
	cout << "C" << " | " << show_grade[2] << "|" << endl;
	cout << "D" << " | " << show_grade[3] << "|" << endl;
	cout << "F" << " | " << show_grade[4] << "|" << endl;
	cout << "_____" << endl;

	Receipt a, b, c, result;


	vector<Receipt>show_reciept{ a,b,c };
	for (auto r : show_reciept)
	{
		std::cin >> a;



	}
	result += a;

	cout << result << endl;


	string name = "GEORGE";
	cout << "This is normal string :" << name << endl << endl;

	str_by_reference(name);
	cout << "string now revered passed by ref :  " << name << endl<<endl; // both variable and value changed since reference allows us to direcly change them inside the memory location
	str_by_value(name);
	cout << "Now string passed by value:  " << name << endl<<endl; // pass by val means we can change only the copy of value of variable and it is not stored in same memory location.
	cout << endl << endl;
	str_by_reference_const(name);
	cout << "Trying to reveres a string that is passed by ref by it is const: " << name << endl;
	cout << "Error! cannot change value of varibale arguemtns  that are passed as  const to function: " << endl;



	//polymorphism

	Line line;

	Shape& shape = line;
	shape.draw(); // virtual allows us to call function that are derived and not base class 

	Cricle circle;

	Shape& circle_c = circle;

	circle_c.draw(); // call method of derived class from base class Shape
	system("pause");
	return 0;
}