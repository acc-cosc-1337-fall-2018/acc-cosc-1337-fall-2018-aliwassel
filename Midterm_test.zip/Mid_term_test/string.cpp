#include "string.h"

void str_by_reference(string  &str) // reverses the string  changes the actual variable and value since it has 
										// dircet acess to its memory location. same memory location access
{
	string reverse_str;
	for (size_t i = str.size(); i != -1; i--)
	{
		reverse_str += str[i];
	}
	str=reverse_str;

}


string str_by_value(string str)						// pass by val means copy of value of variable is send to the function and modified and 
													 // it stored at different location. f
{
	string reveres = "";
	for (unsigned i = str.size(); i != -1; i--)
	{
		reveres += str[i];
	}
	return reveres;
}


void str_by_reference_const(const string& str)
{
	string reverse_str = "";
	for (unsigned i = str.size(); i != -1; i--)
	{
		reverse_str += str[i];

	}
	//str = reverse_str; // Error CANNOT change the parameter since it was declared as const data type.
	//cout << reverse_str << endl; // this might work.
};
