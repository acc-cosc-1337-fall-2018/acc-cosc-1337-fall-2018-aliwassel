#ifndef RECEIPT_H
#define RECEIPT_H
#include<iostream>
#include<string>
using namespace std;
class Receipt
{
public:
	Receipt() = default;
	Receipt(double a) :amount(a) {};
	friend std::istream& operator>>(std::istream& in, Receipt& b);//overwrite >>
	friend std::ostream & operator<<(std::ostream& out, Receipt & d);
	//+= operator does is not part of friend function
	Receipt operator+=(const Receipt & i2);




private:
	double amount{ 0 };
	double get_total(double a)const;
	double get_tip(double a) const;
	double get_tax(double a) const;



};


#endif // !RECIEPT_H

