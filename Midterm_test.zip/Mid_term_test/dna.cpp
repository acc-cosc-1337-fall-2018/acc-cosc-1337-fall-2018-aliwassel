
#include"dna.h"


vector <int >count_dna(string dna) {
	int a{ 0 };
	int g{ 0 };
	int c{ 0 };
	int t{ 0 };
	int null{ 0 };
	for (auto d : dna) {
		switch (d)
		{
		case'a': a++;
			break;
		case 'g': g++;
			break;
		case 'c': c++;
			break;
		case 't': t++;
			break;

		case'A': a++;
			break;
		case 'G': g++;
			break;
		case'C': c++;
			break;
		case'T': t++;
			break;

		default: null++;

		}



	}
	//second vector count the a,c,g,t
	vector <int>dna_count{ a,c,g,t };
	/*dna_count.push_back(a);
	dna_count.push_back(c);
	dna_count.push_back(g);
	dna_count.push_back(t);*/
	return dna_count;
};
