#include "receipt.h"
#include<iomanip>


Receipt Receipt::operator+=(const Receipt & i2) // overloads +=
{
	amount += i2.amount;
	return Receipt(amount);
}

double Receipt::get_tip(double a) const // return tip amount 
{
	return a / 5;
}


double Receipt::get_total(double a) const // calculates total 
// add all to total
{
	double total{ 0 };
	total += a;
	total += get_tip(a);
	total += get_tax(a);
	return total;
}



double Receipt::get_tax(double a) const // calculates tax amount
{
	return a / 10;
}

std::istream & operator>>(std::istream & in, Receipt & b) // overloads the cin operator.  stream extraction.
{
	
	std::cout << "Enter the item value:     " << endl;
	in >> b.amount;
	return in;
}



std::ostream & operator<<(std::ostream & out, Receipt & d) // overloads the cout operator. stream insertion .
{
	out << "Bill Amount:"<<right<<setw(8)<< d.amount << endl;
	out << "Tip Amount:" << right << setw(8)<<d.get_tip(d.amount) << endl;
	out << "Tax Amount:" << right << setw(8) << d.get_tax(d.amount) << endl;
	out << "____________" << right << setw(8)  << endl;
	out << "Total Amount:"<< right << setw(8) << d.get_total(d.amount) << endl;
	
	return out;
}



