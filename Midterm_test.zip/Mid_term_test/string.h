#include<iostream>
#include<string>
using namespace std;

void str_by_reference( string &str); // pass argument by ref
string str_by_value(string str); // pass argument by val 

void str_by_reference_const(const string& str); // pass argument by const ref value of argument cannot be changed.