#include<iostream>
#include<vector>
#include<string>

using namespace std;


vector<int>count_dna(string dna);
//create vect of int that return string
//@param string 
//return vector of int 
