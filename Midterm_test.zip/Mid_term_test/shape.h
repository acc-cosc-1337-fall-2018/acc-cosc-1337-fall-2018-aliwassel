#ifndef SHAPE_H
#define SHAPE_H
#include<iostream>
class Shape {
public:
	virtual void draw() {}

};
class Line : public Shape
{
public:
	void draw() { std::cout << "this is Line: " << endl; }
};

class Cricle : public Shape
{
public:
	void draw() { std::cout << "This is Circle" << endl; }

};


#endif // !SHAPE_H
