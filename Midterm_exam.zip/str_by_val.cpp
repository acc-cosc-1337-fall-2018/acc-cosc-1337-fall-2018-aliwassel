#include "str_by_val.h"

std::string str_by_value(std::string str)
{
	std::string  reverse_str = "";
	for (unsigned i = str.size(); i != -1; i--)
	{
		reverse_str += str[i];
	}
	return reverse_str;
		
}
