//#define CATCH_CONFIG_MAIN
//#include"catch.hpp"
//#include"dna.h"
//#include"grades.h"
//#include"reciept.h"
//#include "shape.h"
//#include "str_by_ref.h"
//#include<string >
//
//TEST_CASE("pass by ref")
//std::string name