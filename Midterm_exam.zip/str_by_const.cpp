#include"str_by_const.h"
#include<iostream>
void str_by_reference(const std::string &str) 
{
	std::string revers_str = "";
	for (int i = str.size(); i != -1; i--) 
	{
		revers_str += str[i];
	}
	//str = revers_str; // error can't change const.
	std::cout << revers_str; // this well work if the argument pass is not const.
}