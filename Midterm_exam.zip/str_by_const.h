#include<string>
#include<iostream>
using namespace std;
void str_by_reference(const std::string &str);